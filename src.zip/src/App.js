import logo from './logo.svg';
import './App.css';
import AddUsers from './Components/Users/AddUsers';
import UserList from './Components/Users/UserList';
import {useState} from 'react'

function App() {
  const [userlist,setuserList] = useState([]);

  const addUserHandler = (uname,uage)=>{
    setuserList((prevlist)=>{
      return [...prevlist,{name:uname,age:uage,id:Math.random().toString()}]
    })
  }
  return (
    <div className="App">
      <AddUsers onUser={addUserHandler}/>
      <UserList users={userlist}/>
    </div>
  );
}

export default App;
