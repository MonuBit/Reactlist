import React from "react"
import Button from "../UI/Button";
import Card from "../UI/Card";
import classes from '../Users/AddUsers.module.css'
import {useState} from 'react'
import ErrorModal from "../UI/ErrorModal";



const AddUsers = props =>{
    const [username,setusername] = useState('')
    const [age,setage] = useState('')
    const [error,setError] = useState()

    const usernameischange = event=>{
       
        setusername(event.target.value)
    }

    const ageischange = event=>{
        setage(event.target.value)
    }
    const errorhandler = ()=>{
        setError('')
    }
    const submithandler = event => {
        event.preventDefault();
        if (username.trim().length === 0 || age.trim().length===0){
            setError({
                title:"Invalid Input",
                message:"Please Enter valid name and age"
            })
            return ;
        }

        if(age<1){
            setError({
                title:"Invalid Age",
                message:"Please Enter valid +ve age"
            })
            return;
        }
        props.onUser(username,age);
        setusername('')
        setage('')

    

        
    };


    return (

        <div>
        {error && <ErrorModal onConfirm = {errorhandler} title = {error.title} message = {error.message}/>}
         <Card className = {classes.input} >
        <form onSubmit={submithandler}>
                <label htmlFor="username">Username</label>
                <input type="text" id="username" value={username} onChange={usernameischange}/>
                <label htmlFor="age">Age </label>
                <input type="number" id="age" value={age} onChange={ageischange}/>
                <Button type="submit">Add user</Button>
        </form>
    </Card>
        </div>
   
   
    )

}

export default AddUsers;